import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-second-categories',
  templateUrl: './order-second-categories.component.html',
  styleUrls: ['./order-second-categories.component.css']
})
export class OrderSecondCategoriesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
