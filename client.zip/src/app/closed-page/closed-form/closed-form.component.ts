import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-closed-form',
  templateUrl: './closed-form.component.html',
  styleUrls: ['./closed-form.component.css']
})
export class ClosedFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
